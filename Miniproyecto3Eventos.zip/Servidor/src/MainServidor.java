/* Angie Joya - 2322609
 * Emily Nuñez - 2240156
 * Sheila Valencia - 2243011
 * Victoria Volveras - 2241874
 */
import Controlador.ControladorServidor;

public class MainServidor {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        ControladorServidor.iniciar();
    }
}
